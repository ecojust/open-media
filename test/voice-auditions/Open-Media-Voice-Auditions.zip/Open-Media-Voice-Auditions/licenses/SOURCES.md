试听音频由本次列出的原创测试语料，使用现有按需下载模型在本地实际生成。

模型来源及许可：https://huggingface.co/csukuangfj/kokoro-int8-multi-lang-v1_1/tree/155831f1b4ba23b1f5c058be6a61df90cefb2a37

模型许可 Apache-2.0，原始文件见 model-LICENSE.txt。完整文件哈希、音色说话人对应、参数与生成记录见 manifest.json。
