window.VOICE_AUDITIONS = [
  {
    "id": "01",
    "title": "原句回归",
    "texts": {
      "zh": "这是一款全程由AI接管并生成的软件",
      "en": "This is an application developed entirely with AI taking charge of the process."
    },
    "focus": "关注 AI 读音、句中连贯性和句尾收束。",
    "audio": {
      "zm_013": "assets/zm_013/01.mp3",
      "zf_038": "assets/zf_038/01.mp3",
      "af_maple": "assets/af_maple/01.mp3"
    }
  },
  {
    "id": "02",
    "title": "功能解说",
    "texts": {
      "zh": "从录制画面到整理素材，再到添加字幕和导出成片，这款软件把常用的创作工具放在了一起。你只需要专注于内容，把想法一步一步变成作品。",
      "en": "From recording your screen and organizing media to adding captions and exporting a finished video, this application brings your creative tools together. Focus on your ideas, and turn them into a story, one step at a time."
    },
    "focus": "并列内容的节奏，以及两句话之间的衔接。",
    "audio": {
      "zm_013": "assets/zm_013/02.mp3",
      "zf_038": "assets/zf_038/02.mp3",
      "af_maple": "assets/af_maple/02.mp3"
    }
  },
  {
    "id": "03",
    "title": "疑问与对话",
    "texts": {
      "zh": "你真的准备好了吗？等一下，先别急着按开始。我们再检查一次声音，好吗？嗯，这次听起来清楚多了，可以开始了。",
      "en": "Are you really ready? Wait a moment. Do not press start just yet. Shall we check the sound one more time? Yes, that sounds much clearer. We are ready to begin."
    },
    "focus": "问句上扬、口语停顿和短句切换。",
    "audio": {
      "zm_013": "assets/zm_013/03.mp3",
      "zf_038": "assets/zf_038/03.mp3",
      "af_maple": "assets/af_maple/03.mp3"
    }
  },
  {
    "id": "04",
    "title": "惊喜与庆祝",
    "texts": {
      "zh": "成功了！我们终于完成了第一个作品！从最初的一个小想法，到现在看得见、听得到的成果，每一步都值得记住。谢谢一直坚持的你！",
      "en": "We did it! Our first project is finally complete! What began as a small idea has become something we can see and hear. Every step matters. Thank you for staying with it!"
    },
    "focus": "感叹句是否有起伏，是否只是增大音量。",
    "audio": {
      "zm_013": "assets/zm_013/04.mp3",
      "zf_038": "assets/zf_038/04.mp3",
      "af_maple": "assets/af_maple/04.mp3"
    }
  },
  {
    "id": "05",
    "title": "温柔安慰",
    "texts": {
      "zh": "没关系，今天没有完成也没关系。先喝一口水，让自己慢慢放松下来。你已经很努力了，剩下的事情，我们明天再一起处理。",
      "en": "It is all right if you did not finish everything today. Take a sip of water, and give yourself a moment to relax. You have worked hard. We can take care of the rest together tomorrow."
    },
    "focus": "柔和语气、呼吸感和句间留白。",
    "audio": {
      "zm_013": "assets/zm_013/05.mp3",
      "zf_038": "assets/zf_038/05.mp3",
      "af_maple": "assets/af_maple/05.mp3"
    }
  },
  {
    "id": "06",
    "title": "故事旁白",
    "texts": {
      "zh": "雨停的时候，街角的灯刚好亮了。她把那封没有寄出的信放进口袋，沿着熟悉的小路往前走。风吹过树叶，她忽然觉得，明天也许会有新的答案。",
      "en": "The rain stopped just as the lights came on at the corner. She slipped the letter she had never sent into her pocket and walked down the familiar path. As the wind moved through the leaves, she wondered whether tomorrow might bring a new answer."
    },
    "focus": "叙事节奏是否稳定，句尾是否过度拖长。",
    "audio": {
      "zm_013": "assets/zm_013/06.mp3",
      "zf_038": "assets/zf_038/06.mp3",
      "af_maple": "assets/af_maple/06.mp3"
    }
  },
  {
    "id": "07",
    "title": "旅行纪录",
    "texts": {
      "zh": "清晨六点，山谷还笼罩在薄雾之中。第一束阳光越过山脊，照亮远处的村庄。我们沿着河流向北出发，去寻找地图上那个没有名字的小镇。",
      "en": "At six in the morning, a thin mist still covered the valley. The first rays of sunlight crossed the ridge and reached the village below. We followed the river north, looking for a small town that had no name on our map."
    },
    "focus": "地点描写和长句是否清楚、连贯。",
    "audio": {
      "zm_013": "assets/zm_013/07.mp3",
      "zf_038": "assets/zf_038/07.mp3",
      "af_maple": "assets/af_maple/07.mp3"
    }
  },
  {
    "id": "08",
    "title": "操作教学",
    "texts": {
      "zh": "首先，把需要剪辑的视频拖入素材区。然后，将片段放到时间线上，移动播放头，找到需要保留的画面。最后检查字幕和背景音乐，确认无误后再导出。",
      "en": "First, drag your video into the media panel. Then place the clip on the timeline and move the playhead to the section you want to keep. Finally, check the captions and background music before exporting your finished video."
    },
    "focus": "步骤层次、停顿，以及关键动词的清晰度。",
    "audio": {
      "zm_013": "assets/zm_013/08.mp3",
      "zf_038": "assets/zf_038/08.mp3",
      "af_maple": "assets/af_maple/08.mp3"
    }
  },
  {
    "id": "09",
    "title": "数字日期与单位",
    "texts": {
      "zh": "今天是2026年10月17日，下午3点30分。视频长度是12.5秒，分辨率为1920乘1080，文件大小约256MB。目前进度为85%，预计还需要2分钟。",
      "en": "Today is October 17, 2026, at 3:30 p.m. The video is 12.5 seconds long, with a resolution of 1920 by 1080 and a file size of about 256 MB. Progress is at 85 percent, with approximately two minutes remaining."
    },
    "focus": "保留原始数字，不预先改写；检查日期、小数、单位、百分比是否误读。",
    "audio": {
      "zm_013": "assets/zm_013/09.mp3",
      "zf_038": "assets/zf_038/09.mp3",
      "af_maple": "assets/af_maple/09.mp3"
    }
  },
  {
    "id": "10",
    "title": "长段落与多音词",
    "texts": {
      "zh": "上个月，我们从重庆出发，经过银行旁边那条长长的街道，重新整理了沿途拍摄的素材。起初，我以为只要把片段按照时间排列，故事就会自然出现。后来才发现，真正重要的是节奏：有些画面需要停留，有些声音应该提前进入，而有些沉默，比解释更有力量。于是，我们删掉了重复的内容，保留了那些看似平常、却让人愿意再看一遍的瞬间。",
      "en": "Last month, we began our journey in Chongqing and organized the footage we had filmed along the way. At first, I thought that putting the clips in order would be enough to tell the story. Later, I realized that rhythm mattered more. Some images needed time to breathe. Some sounds needed to begin before the picture changed. And sometimes, silence was more powerful than an explanation. We removed the repeated scenes and kept the ordinary moments that made us want to watch again."
    },
    "focus": "检查重庆、银行、长长、重新的读音；关注长段落是否漏字、重复或气息断裂。",
    "audio": {
      "zm_013": "assets/zm_013/10.mp3",
      "zf_038": "assets/zf_038/10.mp3",
      "af_maple": "assets/af_maple/10.mp3"
    }
  }
];
