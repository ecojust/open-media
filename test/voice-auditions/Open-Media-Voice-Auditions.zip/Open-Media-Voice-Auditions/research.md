# 按需下载语音模型：以音质优先的候选核验

核验日期：2026-10-17。本文记录模型来源、下载量与运行路径，**不代表这些候选已接入 Open Media，也不代表已完成实际试听**。本轮 30 条试听属于目前已接入的三个可下载音色；它们共用一个轻量模型包。

## 建议

不再用下载体积筛掉高品质候选。下一轮优先测试 **Qwen3-TTS 1.7B CustomVoice 的 BF16 版本**，同时用 8bit 版本对照同一语料；它有固定音色、语气指令和明确的可再分发许可证，最符合“点击音色卡片、下载后直接配音”的方式。保留当前内置模型作为免下载入口。

第二候选是 **Fun-CosyVoice3**，侧重中文自然度、方言和语气。它主要由参考音频决定音色，需要准备有授权的参考素材后才能做成稳定的音色卡片。

**IndexTTS-2.5** 可用于更精细的情绪/时长控制；**Drama 3** 可作为高内存机器的长篇、多角色候选。后两者有自定义模型许可证，需要在提供下载时保留条款，不能写成“无限制商用”。

## 可核验的下载量与能力

所有大小均通过 Hugging Face 模型元数据 `?blobs=true` 逐文件求和；单位 GB 为十进制。它们是对应仓库的文件总量，**不是运行内存**。最终安装包还要统计运行时、必要依赖和参考音频；不能直接把仓库总量当成最终下载量。

| 模型/格式 | 核验仓库文件总量 | 音色方式 | Apple 芯片路径与边界 |
| --- | ---: | --- | --- |
| Qwen3-TTS 1.7B CustomVoice BF16 / MLX | 4,520,195,613 B，4.52 GB | 固定 9 个音色；支持语气指令 | MLX-Audio 有专用实现；尚未在本项目/macOS 真机实测 |
| 同上 8bit / MLX | 3,080,141,538 B，3.08 GB | 同一组 9 个音色 | 适合与 BF16 做盲听对照；不预先承诺量化无音质变化 |
| 同上 4bit / MLX | 2,312,059,416 B，2.31 GB | 同一组 9 个音色 | 可以作为节省内存的备选，不作为此次音质优先的默认 |
| Fun-CosyVoice3 0.5B / 官方仓库 | 9,747,516,745 B，9.75 GB | 参考音频决定音色，支持指令 | 仓库包含替代权重/导出文件，实际安装应只取必要文件 |
| Fun-CosyVoice3 0.5B 4bit / MLX | 1,228,599,602 B，1.23 GB | 参考音频及可选转写/语气指令 | 社区 MLX-Audio-Plus 实现；此仓库文件总量不能证明依赖也已齐全，需要实际验证 |
| IndexTTS-2.5 FP16 / MLX | 4,481,043,854 B，4.48 GB | 参考音频、情绪控制 | 社区实现；需要核验下载的全部组件及许可后实测 |
| Drama 3 4bit / MLX | 23,781,118,816 B，23.78 GB | 参考音频，多角色标记 | 实现文档报告 M3 Max 峰值约 26 GB；是上游测试，非本项目结果。一般需 32 GB 以上统一内存才有实测意义 |

官方 Qwen3 1.7B BF16 仓库总量为 4,520,218,951 B，与 MLX 转换版略有差异；主要权重 3,833,402,552 B，语音 tokenizer 权重 682,293,092 B，不能漏算后者。

### Qwen3 固定音色完整列表

| 音色 ID | 官方描述的主要特征 | 原生语言 |
| --- | --- | --- |
| Vivian | 明亮、略有棱角的年轻女声 | 中文 |
| Serena | 温暖、柔和的年轻女声 | 中文 |
| Uncle_Fu | 成熟、低沉醇厚的男声 | 中文 |
| Dylan | 清晰自然的北京青年男声 | 中文/北京口音 |
| Eric | 活泼、略带沙哑的成都男声 | 中文/四川口音 |
| Ryan | 节奏感强的活力男声 | 英文 |
| Aiden | 阳光、清晰中音域的美国男声 | 英文 |
| Ono_Anna | 轻快俏皮的女声 | 日语 |
| Sohee | 温暖、情绪丰富的女声 | 韩语 |

官方说明每个音色可以生成所支持的其他语言，但推荐原生语言获取最佳质量。**固定音色中没有英文原生女声**；要维持软件目前“英文女声”分类，应保留已验证音色，或另行试听跨语种女声/VoiceDesign 方案，不能只改名称冒充。

## 本次真实运行边界

当前工作机为 Linux x86_64 CPU 环境，不能用它给出 macOS MLX 的实际速度/内存结论。Qwen 官方示例主要用 PyTorch CUDA；CosyVoice 官方源码包含无 CUDA 的降级路径，但这不等于 CPU 能达到交互速度。没有下载或运行本文的大模型，因此没有这几个候选的主观音质、漏字率或吞吐实测结论。

公开的 Artificial Analysis / TTS Arena 排名以英文试听为主；不能据此宣称某模型中文排名第一。是否纳入可下载音色，应以同语料实际试听和目标设备测量为准。

建议每个候选音色固定测试 10 类语料：产品介绍、日常对话、疑问/反问、新闻播报、故事叙述、情绪表达、数字日期金额、中文多音字、中英混读、较长句与停顿。记录模型版本、推理参数、生成用时、峰值内存、音频时长；试听重点看机械感、重音、断句、错漏字与尾音截断。

## 官方来源与可复核版本

1. Qwen 官方能力与音色列表：<https://github.com/QwenLM/Qwen3-TTS#custom-voice-generation>；官方权重与 Apache-2.0：<https://huggingface.co/Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice>，版本 `0c0e3051f131929182e2c023b9537f8b1c68adfe`。
2. Qwen 的 MLX 推理说明：<https://github.com/Blaizzy/mlx-audio/blob/main/mlx_audio/tts/models/qwen3_tts/README.md>。
3. Qwen MLX BF16：<https://huggingface.co/mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-bf16>，版本 `52f4770fd9726457eae3d3b6aa92047a25a10776`；8bit：<https://huggingface.co/mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-8bit>，版本 `41d3337e8b7f2843a75841595fc14e4b9a7a4b96`；4bit：<https://huggingface.co/mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-4bit>，版本 `f35faf19b0cc2160865af64ecf0f22f83d335135`。
4. CosyVoice 官方源码：<https://github.com/FunAudioLLM/CosyVoice>；官方权重及 Apache-2.0：<https://huggingface.co/FunAudioLLM/Fun-CosyVoice3-0.5B-2512>，版本 `29e01c4e8d000f4bcd70751be16fa94bf3d85a18`。
5. CosyVoice 社区 MLX 转换及用法：<https://huggingface.co/mlx-community/Fun-CosyVoice3-0.5B-2512-4bit>，版本 `55a6713d54751f1ec2645aa11294676f2067202a`；运行库 <https://github.com/DePasqualeOrg/mlx-audio-plus>。转换卡未单独标出 license 字段，应沿用/保留上游许可，并核对所有额外依赖。
6. IndexTTS 官方权重：<https://huggingface.co/IndexTeam/IndexTTS-2.5>；自定义条款：<https://huggingface.co/IndexTeam/IndexTTS-2.5/blob/main/LICENSE>。对超过 1 亿月活或上一年营收超过人民币 10 亿元等情况要求另行授权，并要求下游遵守条款。
7. IndexTTS 社区 MLX：<https://huggingface.co/mlx-community/IndexTTS-2.5-fp16>，版本 `65644cd70da15309ffeb74aa03f3686bb04e3eb1`。仓库卡提供实现入口及组件说明。
8. Drama 3 官方权重：<https://huggingface.co/fishaudio/drama-3>；Community License（2026-10-13）：<https://huggingface.co/fishaudio/drama-3/blob/main/LICENSE>。一般社区商业使用有年营收低于 50 万美元的门槛，托管服务另有要求。
9. Drama 3 社区 MLX 4bit：<https://huggingface.co/mlx-community/fish-audio-drama-3-4bit>，版本 `cc639e27aba7edb73429d3e3806f471dcd79d316`；实现及内存测试说明：<https://github.com/Blaizzy/mlx-audio/blob/main/docs/models/tts/fish-drama3.md>。
10. 英文试听榜方法和样本：<https://artificialanalysis.ai/text-to-speech/leaderboard/provider-voice>、<https://github.com/TTS-AGI/TTS-Arena/blob/main/apps/docs/content/docs/ranking.mdx>。这些榜单不能替代中文语料验证。

## 接入时的具体原则

- 同一模型包的多个音色共用下载与缓存，只下载一次，不为每张卡重复占用数 GB。
- 卡片显示实际待下载字节数、已安装状态与运行内存要求；“下载体积”和“运行内存”分开。
- 模型在下载后离线运行；播放试听使用提前生成的本地音频。
- 先试听确定保留的音色，再实现对应推理运行时；没有集成的模型不显示为已可下载使用。
- 原始模型版本及 SHA-256 固定，下载中断可恢复，验证通过后才切换为可用状态。
